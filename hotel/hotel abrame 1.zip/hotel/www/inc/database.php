<?php
function dbConnexion(){
    $connexion = null;
    try{
        $connexion = new PDO("mysql:host=db.hotel.com;dbname=hotel_db", "admin", "admin");
    }catch(PDOException $e){
        $connexion = $e->getMessage();
    }
    return $connexion;
}