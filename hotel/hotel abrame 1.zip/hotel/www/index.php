<?php include_once "inc/header.php"; ?>

<!-- le contenu de la page d'accueil -->

<?php include_once "inc/footer.php"; ?>