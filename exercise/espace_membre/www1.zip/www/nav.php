<nav>
    <button><a href="connexion.php">Connexion</a></button>
</nav>