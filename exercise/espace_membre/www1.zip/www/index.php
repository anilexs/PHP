<?php
echo "salut";